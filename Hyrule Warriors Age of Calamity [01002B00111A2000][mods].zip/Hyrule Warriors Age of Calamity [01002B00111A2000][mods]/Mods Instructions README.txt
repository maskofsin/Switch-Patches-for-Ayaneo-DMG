- Ultrawide mods set resolution to 1240x1080 to avoid visual glitches
- Ultrawide mods and Resolution mods cant be used togheter
- Adjusted HUD mod will glitch minimap position a bit
- The Improved Quality mod has a significant impact on performance

// Converted to 8:7 (1240x1080) for Ayaneo DMG